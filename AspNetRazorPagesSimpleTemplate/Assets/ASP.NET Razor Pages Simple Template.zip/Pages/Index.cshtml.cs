using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace $safeprojectname$.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
